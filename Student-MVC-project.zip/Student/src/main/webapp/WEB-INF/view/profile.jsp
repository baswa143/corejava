<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
       <%@ page isELIgnored = "false" %>
<!DOCTYPE html>
<html>
<head>
    <title>Success</title>
</head>

<body>

<h1>Student Saved Successfully</h1>

 <h2>Student_Name: ${student.name}</h2>
<h2> Student_Email: ${student.email}</h2>
<h2> Student_password: ${student.password}</h2>

</body>
</html>