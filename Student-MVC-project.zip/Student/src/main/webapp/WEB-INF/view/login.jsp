<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Student Form</title>
<style>

    body{
        font-family: Arial, sans-serif;
        background-color: #f2f2f2;
        margin:80px
    }

    .container{
        width: 400px;
        margin: 80px auto;
        background-color: white;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0px 0px 10px gray;
    }

    h1{
        text-align: center;
        color: #007bff;
    }

    input[type=text],
    input[type=password]{

        width: 100%;
        padding: 10px;
        margin-top: 5px;
        margin-bottom: 20px;

        border: 1px solid #ccc;
        border-radius: 5px;
    }

    input[type=submit]{

        width: 100%;
        padding: 10px;
        background-color: #007bff;
        color: white;

        border: none;
        border-radius: 5px;

        font-size: 16px;
        cursor: pointer;
    }

    input[type=submit]:hover{
        background-color: #0056b3;
    }

    label{
        font-weight: bold;
    }

</style>
</head>

<body>

<h1>Student Registration</h1>

<form action="save" method="post">

    Name :
    <input type="text" name="name"/>

    <br><br>

    Email :
    <input type="text" name="email"/>

    <br><br>

    Password :
    <input type="password" name="password"/>

    <br><br>

    <input type="submit" value="Save Student"/>

</form>

</body>
</html>